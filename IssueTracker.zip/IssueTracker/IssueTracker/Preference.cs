﻿namespace P5
{
    public class Preference
    {
        public string UserName { get; set; }
        public string Name { get; set; }
        public string Value { get; set; }
    }
}
